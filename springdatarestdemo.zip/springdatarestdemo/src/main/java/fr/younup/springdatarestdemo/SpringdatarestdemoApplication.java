package fr.younup.springdatarestdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdatarestdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringdatarestdemoApplication.class, args);
	}

}
